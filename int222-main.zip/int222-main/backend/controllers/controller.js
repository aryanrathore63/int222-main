export const getHello = async (req, res) => {
    res.send('Hello World!');
};