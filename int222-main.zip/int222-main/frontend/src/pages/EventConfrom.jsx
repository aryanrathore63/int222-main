import React from "react";
import { FaRegEyeSlash } from "react-icons/fa6";
import { MdContentCopy } from "react-icons/md";
import Header from "../components/EventConform/Header";
import HeaderMenu from "../components/EventConform/HeaderMenu";
const EventConfrom = () => {
  return (
    <div className="  px-10 py-10">
      <Header />
      <HeaderMenu />
    </div>
  );
};

export default EventConfrom;
